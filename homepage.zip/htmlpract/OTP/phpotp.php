<!DOCTYPE html>
<?php
if (isset($_POST['login'])) {

	$username = "mallinathkhonde4@gmail.com";
	$hash = "d1c935e0c6c3f976a724651b34e255b7d6e550405ae79f3fe252ba5373955f0d";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";
	$name = $_POST['name'];


	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = $_POST['num']; // A single number or a comma-seperated list of numbers
	$otp = mt_rand(100000,999999);
	setcookie("otp",$otp);
	$message = "Hey".$name."Your OTP IS".$otp;
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	echo ("OTP SEND SUCCESSFULLY");
	curl_close($ch);

    }
if (isset($_POST['ver'])) {
	$verotp=$_POST['otp'];
	if ($verotp==$_COOKIE['otp']) {
		echo("'verified Successfully");
		
	}else{
		echo("Invaild OTP");
	}
     
}    

?>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<form method="post" action="phpotp.php">
		<table align="center">
			<tr>
				<td>Name</td>
				<td><input type="text"  name="name" placeholder="Enter your Name"></td>
			</tr>
			<tr>
				<td>Mobile Number</td>
				<td><input type="text" name="num" placeholder="valid with country"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="login" value="send otp"></td>
			</tr>
			<tr>
				<td>Verify OTP:</td>
				<td><input type="text" name="otp" ></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="ver" value="Verify otp" style="background-color: green; border: 0px;"></td>
			</tr>
	</form>

</body>
</html>